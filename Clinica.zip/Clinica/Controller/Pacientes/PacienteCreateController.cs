using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Clinica.Models;
using Clinica.Services;
using Clinica.Services.Pacientes;

namespace Clinica.Controller.Pacientes
{
    [ApiController]
    [Route("api/[controller]")]
    public class PacienteCreateController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;

        public PacienteCreateController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        [HttpPost]
        public IActionResult Create([FromBody] Paciente paciente)
        {
            _pacienteRepository.Add(paciente);
            return Ok();
        }
    }
}