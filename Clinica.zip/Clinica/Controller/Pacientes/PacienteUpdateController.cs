using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Clinica.Models;
using Clinica.Services;
using Clinica.Services.Pacientes;
using Microsoft.AspNetCore.Mvc;

namespace Clinica.Controller.Pacientes
{   
    [ApiController]
    [Route("api/[controller]")]
    public class PacienteUpdateController : ControllerBase
    {
         private readonly IPacienteRepository _pacienteRepository;

        public PacienteUpdateController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Paciente paciente)
        {
            if (id != paciente.Id)
            {
                return BadRequest("ID mismatch");
            }

            var existingPaciente = _pacienteRepository.GetById(id);
            if (existingPaciente == null)
            {
                return NotFound();
            }

            bool updateResult = await _pacienteRepository.Update(paciente);

            if (!updateResult)
            {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            return NoContent();
        }
    }
}