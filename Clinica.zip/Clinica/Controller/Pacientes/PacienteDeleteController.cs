using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Clinica.Models;
using Clinica.Services;
using Clinica.Services.Pacientes;

namespace Clinica.Controller.Pacientes
{
    [ApiController]
    [Route("api/[controller]")]
    public class PacienteDeleteController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;

        public PacienteDeleteController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var paciente = _pacienteRepository.GetById(id);
            if (paciente == null)
            {
                return NotFound();
            }

            _pacienteRepository.Remove(id);
            return NoContent();
        }
    }
}