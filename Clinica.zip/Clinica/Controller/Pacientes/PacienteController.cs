using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Clinica.Models;
using Clinica.Services;
using Clinica.Services.Pacientes;

namespace Clinica.Controller.Pacientes
{   
    [ApiController]
    [Route("api/[controller]")]
    public class PacienteController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;

        public PacienteController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

          [HttpGet]
        public IEnumerable<Paciente> GetAuthors()
        {
            return _pacienteRepository.GetAll();
        }

        [HttpGet]
        [Route("{id}")]
        public Paciente Details(int id)
        {
            return _pacienteRepository.GetById(id);
        }
    }
}