using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Clinica.Models;

namespace Clinica.Services.Pacientes
{
    public interface IPacienteRepository
    {
        IEnumerable<Paciente> GetAll();
        Paciente GetById(int id);
        void Add(Paciente paciente);
        void Remove(int id);
        Task<bool> Update(Paciente paciente);

    }
}