using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Clinica.Data;
using Clinica.Models;
using Microsoft.EntityFrameworkCore;

namespace Clinica.Services.Pacientes
{
    public class PacienteRepository : IPacienteRepository
    {
        private readonly BaseContext _context;

        public PacienteRepository(BaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Paciente> GetAll()
        {
            return _context.Pacientes.ToList();
        }

        public Paciente GetById(int id)
        {
            return _context.Pacientes.Find(id);
        }
        public void Add(Paciente paciente)
        {
            _context.Pacientes.Add(paciente);
            _context.SaveChanges();
        }
        public void Remove(int id)
        {
            var paciente = _context.Pacientes.Find(id);
            _context.Pacientes.Remove(paciente);
            _context.SaveChanges();
        }

        public async Task<bool> Update(Paciente paciente)
        {
            _context.Entry(paciente).State = EntityState.Modified;
            return await _context.SaveChangesAsync() > 0;
        }
    }
}