
CREATE TABLE pacientes (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Nombres VARCHAR(125),
  Apellidos VARCHAR(125),
  FechaNacimiento DATE,
  Correo VARCHAR(125),
  Telefono VARCHAR(75),
  Direccion VARCHAR(125),
  Estado ENUM("activo", "inactivo", "eliminado")
)

CREATE TABLE especialidades (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Nombre VARCHAR(125),
  Descripcion TEXT,
  Estado ENUM("activo", "inactivo", "eliminado"))

  CREATE TABLE medicos (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    NombreCompleto VARCHAR(125),
    EspecialidadId INTEGER,
    Correo VARCHAR(125),
    Telefono VARCHAR(75),
    Estado ENUM("activo", "inactivo", "eliminado"),
    FOREIGN KEY (EspecialidadId) REFERENCES especialidades(id)
  )

  CREATE TABLE citas (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    MedicoId INTEGER,
    PacienteID INTEGER,
    Fecha DATE,
    Estado ENUM("activo", "inactivo","eliminado"),
    FOREIGN KEY (MedicoId) REFERENCES medicos(id),
    FOREIGN KEY (PacienteId) REFERENCES pacientes(id)
  )

  CREATE TABLE tratamientos (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    CitaId INTEGER,
    Descripcion TEXT,
    Estado ENUM("activo", "inactivo", "eliminado"),
    FOREIGN KEY (CitaId) REFERENCES citas(id)
  )