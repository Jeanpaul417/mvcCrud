using Microsoft.EntityFrameworkCore;
using Crud_Videojuegos.Models;
using Crud_Videojuegos.Data;

namespace Crud_Videojuegos.Data
{
    public class BaseContext : DbContext
    {
        public BaseContext(DbContextOptions<BaseContext> options) : base(options){

        }

        public DbSet<Videojuego> Videojuegos { get; set; }
    }

}