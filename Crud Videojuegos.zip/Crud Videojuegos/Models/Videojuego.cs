
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace Crud_Videojuegos.Models
{
    public class Videojuego
    {
        [Key]
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Image { get; set; }
        public string? Description { get; set; }
        public int Amount { get; set; }
        public DateOnly? ReleaseDate { get; set; }
        public string? CompatibleConsole { get; set; }
        public bool? PlayableOnline { get; set; }

    }
}