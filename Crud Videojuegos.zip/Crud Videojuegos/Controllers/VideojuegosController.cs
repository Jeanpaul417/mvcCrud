using Crud_Videojuegos.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Crud_Videojuegos.Controllers
{
    public class VideojuegosController : Controller
    {
        public readonly BaseContext _context;

        public VideojuegosController(BaseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(){
            return View(await _context.Videojuegos.ToListAsync());
        }

         public async Task<IActionResult> Details(int id){

            return View(await _context.Videojuegos.FirstOrDefaultAsync(m=> m.Id == id));
        }
    }
}