CREATE TABLE Videojuegos (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(45),
    Image VARCHAR(255),
    Description TEXT,
    Amount INT,
    ReleaseDate DATE,
    CompatibleConsole VARCHAR(255),
    PlayableOnline BOOLEAN DEFAULT true
)

INSERT INTO `Videojuegos` (`Name`, `Image`, `Description`, `Amount`, `ReleaseDate`, `CompatibleConsole`, `PlayableOnline`) VALUES ('Dios de la guerra 1',
'https://i.3djuegos.com/juegos/3569/god_of_war/fotos/ficha/god_of_war-2736533.jpg', 'Un comienzo totalmente nuevo: la venganza de Kratos contra los dioses del Olimpo ha quedado atrás y ahora vive como un hombre en las tierras de los dioses y monstruos nórdicos. Será en este mundo hostil y sin piedad donde deberá luchar para sobrevivir... y donde deberá enseñar a su hijo a hacer lo mismo.',
1,'2009-11-17', 'Play Station 1',TRUE)


INSERT INTO `Videojuegos` (`Id`, `Name`, `Image`, `Description`, `Amount`, `ReleaseDate`, `CompatibleConsole`, `PlayableOnline`) VALUES (4,'Mafia 2',
'https://www.juegosdigitalescolombia.com/files/images/productos/1618706960-mafia-ii-definitive-edition-ps4.jpg', 'Mafia II es un videojuego de acción en tercera persona desarrollado por 2K Games. Es la continuación de la primera entrega Mafia: The City of Lost Heaven, aunque no posee continuidad directa con la línea argumentativa de esta. Su creación y desarrollo fue anunciada el 22 de agosto de 2008 en la convención de Juegos de Leipzig. En ésta, el póster oficial del juego, el logo y el tráiler fueron presentados al público.4​5​',
2,'2010-08-23', 'Play Station 4',FALSE)