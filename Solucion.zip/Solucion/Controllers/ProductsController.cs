using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Solucion.Data;


namespace Solucion.Controllers
{
    public class ProductsController : Controller
    {
        public readonly BaseContext _context;

        public ProductsController(BaseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(){
            return View(await _context.Products.ToListAsync());
        }
    }
}