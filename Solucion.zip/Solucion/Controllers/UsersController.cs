using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Solucion.Data;
using Solucion.Models;


namespace Solucion.Controllers
{
    public class UsersController : Controller
    {
        public readonly BaseContext _context;

        public UsersController(BaseContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index(){
            return View(await _context.Users.ToListAsync());
            // select * form Users
        }

         public async Task<IActionResult> Details(int? id){
      return View(await _context.Users.FirstOrDefaultAsync(m => m.Id == id));
        }

/*          public IActionResult Delete(int? id){
            var user = _context.Users.FirstOrDefault(m => m.Id == id);
            _context.Users.Remove(user);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
 */
        //Eliminar del profesor

        public async Task<IActionResult> Delete(int id){
            // Buscamos en la base de datos
            var user = await _context.Users.FindAsync(id);
            // Elimina un objeto del Dbset Users que esta dentro del contexto de la base de datos
            _context.Users.Remove(user);
            // Es responsable de guardar los cambios realizados en el contexto de la base de datos de forma asincrona
            await _context.SaveChangesAsync();
            // nos vamkos pa otra vista
            return RedirectToAction("Index");
        }
        
        public IActionResult Edit(int? id){
            var user = _context.Users.FirstOrDefault(m => m.Id == id);
            _context.SaveChanges();
            return View(user);
        }

       /*  public IActionResult Crear()
            {
                return View();
            } */
        
        public async Task<IActionResult> Crear(User nuevoUsuario)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(nuevoUsuario);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index"); // Redireccionar a donde quieras después de guardar el producto
            }
            return View(nuevoUsuario); // Enviar de vuelta al formulario si hay errores de validación
        }

    }
}