using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Solucion.Data;
using Solucion.Models;


namespace Solucion.Controllers
{
  public class UsersController : Controller
  {
    public readonly BaseContext _context;

    public UsersController(BaseContext context)
    {
      _context = context;
    }
    public async Task<IActionResult> Index()
    {
      return View(await _context.Users.ToListAsync());
      // select * form Users
    }

    public async Task<IActionResult> Details(int? id)
    {
      return View(await _context.Users.FirstOrDefaultAsync(m => m.Id == id));
    }

    /*          public IActionResult Delete(int? id){
                var user = _context.Users.FirstOrDefault(m => m.Id == id);
                _context.Users.Remove(user);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
     */
    //Eliminar del profesor

    public async Task<IActionResult> Delete(int id)
    {
      // Buscamos en la base de datos
      var user = await _context.Users.FindAsync(id);
      // Elimina un objeto del Dbset Users que esta dentro del contexto de la base de datos
      _context.Users.Remove(user);
      // Es responsable de guardar los cambios realizados en el contexto de la base de datos de forma asincrona
      await _context.SaveChangesAsync();
      // nos vamkos pa otra vista
      return RedirectToAction("Index");
    }



    public IActionResult Crear()
    {
      return View();
    }

    // Método para manejar la solicitud de creación de usuario
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Crear([Bind("Names,LastNames,Email,BirthDate")] User usuario)
    {
      if (ModelState.IsValid)
      {
        // Guardar el nuevo usuario en la base de datos
        _context.Users.Add(usuario);
        await _context.SaveChangesAsync();
        return RedirectToAction("Index"); // Redirigir a la página principal u otra página deseada
      }
      return View(usuario);
    }


/* METODO Editar */
[HttpGet]
public async Task<IActionResult> Edit(int id)
{
    // Buscar el usuario en la base de datos utilizando el ID proporcionado
    var usuario = await _context.Users.FindAsync(id);

    if (usuario == null)
    {
        return NotFound(); // Si el usuario no se encuentra, devolver un error 404
    }

    return View(usuario); // Pasar el usuario encontrado a la vista de edición
}

[HttpPost]
[ValidateAntiForgeryToken]
public async Task<IActionResult> Edit(int id, [Bind("Id,Names,LastNames,Email,BirthDate")] User usuario)
{
    if (id != usuario.Id)
    {
        return NotFound(); // El ID del usuario no coincide con el ID proporcionado en el formulario
    }

    if (ModelState.IsValid)
    {
        try
        {
            // Buscar el usuario en la base de datos
            var userToUpdate = await _context.Users.FindAsync(id);

            if (userToUpdate == null)
            {
                return NotFound(); // No se encontró el usuario en la base de datos
            }

            // Actualizar las propiedades del usuario con los valores del modelo recibido del formulario
            userToUpdate.Names = usuario.Names;
            userToUpdate.LastNames = usuario.LastNames;
            userToUpdate.Email = usuario.Email;
            userToUpdate.BirthDate = usuario.BirthDate;

            // Guardar los cambios en la base de datos
            _context.Update(userToUpdate);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index)); // Redirigir a la página principal
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!UserExists(usuario.Id))
            {
                return NotFound(); // Si el usuario no existe en la base de datos
            }
            else
            {
                throw; // Si ocurre algún otro error durante la actualización
            }
        }
    }
    return View(usuario); // Devolver la vista de edición con el modelo usuario
}

private bool UserExists(int id)
{
    return _context.Users.Any(e => e.Id == id);
}



    //BUSCADOR

    public IActionResult Buscar(string searchString)
    /*  Este método es un controlador de acción HTTP que maneja las solicitudes de búsqueda. 
    Toma un parámetro searchString, que es la cadena que el usuario está buscando en la base de datos. */
    {
      var users = _context.Users.AsQueryable();
    /* Se inicializa una variable users que representa la consulta a la base de datos de usuarios. 
    AsQueryable() convierte la colección de usuarios en una consulta IQueryable, 
    que permite construir consultas LINQ sobre ella. */
      if (!string.IsNullOrEmpty(searchString))
      /*  Se verifica si la cadena de búsqueda no está vacía ni nula. */
      {
        users = users.Where(u => u.Names.Contains(searchString) || u.LastNames.Contains(searchString));
        /* Si la cadena de búsqueda no está vacía, se filtran los usuarios en base a sus nombres (Names) 
        o apellidos (LastNames) contienen la cadena de búsqueda. Esto se hace utilizando la función Where de LINQ,
         que filtra los elementos de una secuencia basándose en un predicado. */
      }

      return View("Busqueda", users.ToList());
      /* Finalmente, se devuelve una vista llamada "Busqueda" con la lista de usuarios filtrados como modelo. 
      users.ToList() convierte la consulta IQueryable en una lista concreta de usuarios. Esta vista probablemente 
      mostrará los usuarios encontrados en una tabla o de alguna otra manera adecuada para la interfaz de usuario. */
    }
  }
}



/* IQueryable es una interfaz en el espacio de nombres System.Linq en 
.NET que representa una secuencia de elementos que se pueden consultar. 
Esta interfaz se utiliza comúnmente en el contexto de LINQ (Language Integrated Query),
 que es una característica de C# y otros lenguajes de programación 
 En .NET permite escribir consultas de bases de datos y operaciones de filtrado, 
 ordenamiento y proyección sobre colecciones de datos de una manera muy similar a SQL. */