DROP TABLE Users


CREATE TABLE Users (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Names VARCHAR(50),
    LastNames VARCHAR(50) ,
    Email VARCHAR(100),
    BirthDate DATE
);


INSERT INTO `Users` (`id`, `Names`, `LastNames`, `Email`, `BirthDate`) VALUES ('Dina', 'Martinez', 'dina@gmail.com','2022-11-14');

INSERT INTO `Users` (`id`, `Names`, `LastNames`, `Email`, `BirthDate`) VALUES (3, 'Juan Pablo', 'Giraldo', 'juan@gmail.com','2087-11-14');

INSERT INTO `Users` (`Id`, `Names`, `LastNames`, `Email`, `BirthDate`) VALUES (9, 'Vikingo', 'Arboledad', 'vikingo@gmail.com','1998-06-14');


CREATE Table Products (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50),
    Description VARCHAR(100),
    Price DOUBLE,
    Aumount VARCHAR(50),
    ExpirationDate DATE,
    Address VARCHAR(45),
    Phone VARCHAR(45),
    UserId INT
)



INSERT INTO `Products` (`id`, `Name`, `Description`, `Price`, `Aumount`,`ExpirationDate`,`Address`,`Phone`,`UserId`) 
VALUES (5, 'Piña', 'Fruta', 20000,'10','2024-06-15','Bodega01','3456978',001);

INSERT INTO `Products` (`id`, `Name`, `Description`, `Price`, `Aumount`,`ExpirationDate`,`Address`,`Phone`,`UserId`) 
VALUES (3, 'Mora', 'Fruta', 30000,'5','2024-05-15','Bodega01','3456978',002);


ALTER TABLE Products ADD FOREIGN KEY (UserId) REFERENCES Users(Id)