DROP TABLE Users


CREATE TABLE Users (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Names VARCHAR(50),
    LastNames VARCHAR(50) ,
    Email VARCHAR(100),
    BirthDate DATE
);


INSERT INTO `Users` (`id`, `Names`, `LastNames`, `Email`, `BirthDate`) VALUES (2, 'Dina', 'Martinez', 'dina@gmail.com','2022-11-14');


CREATE Table Products (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50),
    Description VARCHAR(100),
    Price DOUBLE,
    Aumount VARCHAR(50),
    ExpirationDate DATE,
    Address VARCHAR(45),
    Phone VARCHAR(45),
    UserId INT
)