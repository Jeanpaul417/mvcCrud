


using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Microsoft.EntityFrameworkCore.Storage;

namespace Solucion.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string? Names { get; set; }
        public string? LastNames { get; set; }

        public string? Email { get; set; }

        public DateTime? BirthDate { get; set; }
    }

}