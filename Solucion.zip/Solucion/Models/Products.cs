

using System.Globalization;
using Microsoft.EntityFrameworkCore.Storage;

namespace Solucion.Models
{
    public class Product
    {
        public int Id { get; set; }

        public string? Name {get;set;}

        public string? Description {get;set;}

        public Double? Price {get; set;}

        public string? Aumount {get; set;}

        public DateTime? ExpirationDate {get;set;}

        public string? Address {get;set;}

        public string? Phone {get; set;}

    }
}