CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(45),
    Nit INT,
    Address VARCHAR(45),
    Description TEXT(45),
    Logo VARCHAR(255),
    LegalRepresentative VARCHAR(255)
)


INSERT INTO Companies(Name,Nit, Address, Description, Logo, LegalRepresentative)
VALUES ('Cocacola','98786465','Carrera 90 # 45-60','Empresa de comercializadora de bebidas','https://upload.wikimedia.org/wikipedia/commons/2/24/Coca-Cola_bottle_cap.svg',
'Juan Pablo Giraldo Meneses')


INSERT INTO Companies(Name,Nit, Address, Description, Logo, LegalRepresentative)
VALUES ('Postobon','32145698','Carrera 50 # 66-60','Empresa comercializadora de bebidas','https://www.celuweb.com/wp-content/uploads/2020/05/postobonlogo.jpg',
'Juan Pablo Giraldo Meneses')