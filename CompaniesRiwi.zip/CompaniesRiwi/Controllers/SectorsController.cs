using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompaniesRiwi.Data;
using CompaniesRiwi.Models;



namespace CompaniesRiwi.Controllers
{
    public class SectorsController : Controller
    {
        public readonly BaseContext _context;
        public SectorsController(BaseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Sectors.ToListAsync());
        }

        /* CREAR *******************************************************/

        public IActionResult Create()
        {
            return View();
        }

        // Con esta vista lo que hacemos es poder pasarle el dato a crear lo agrege al contexto y actualize el contexto para poder indicar que se creo correctamente
        [HttpPost]
        public IActionResult Create(Sector u)
        {
        // Se agrega el usuario al dbset dentro de los modelos donde se esta mapeando los datos
        _context.Sectors.Add(u);
        // Guarda los cambios del dbset en la Base de Datos
        _context.SaveChanges();
        // Redirecciona a la lista de Usuarios
        return RedirectToAction("index");
        }


        //Detalles ****************************************************************
         public async Task<IActionResult> Details(int id){

            return View(await _context.Sectors.FirstOrDefaultAsync(m=> m.Id == id));
        }

         /* Eliminar ***********************************************/

        public async Task<IActionResult> Delete(int id){
             var user = await _context.Sectors.FindAsync(id);
            _context.Sectors.Remove(user); 
            await _context.SaveChangesAsync(); 
            return RedirectToAction("Index"); 
        }


                /* Editar */

        public async Task<IActionResult> Edit(int? id)
            {
            return View(await _context.Sectors.FirstOrDefaultAsync(m => m.Id == id));
            }

        [HttpPost]
        public IActionResult Edit(int id, Sector user)
        {
        // Se agrega el usuario al dbset dentro de los modelos donde se esta mapeando los datos
        _context.Sectors.Update(user);
        // Guarda los cambios del dbset en la Base de Datos
        _context.SaveChanges();
        // Redirecciona a la lista de Usuarios
        return RedirectToAction("index");
        }


         // Método para el buscar en la base de datos
        public async Task<IActionResult> Search(string? searchString)
        {
        var users = _context.Sectors.AsQueryable();
        if (!string.IsNullOrEmpty(searchString))
        {
            users = users.Where(u => u.Name.Contains(searchString) || u.Description.Contains(searchString) || u.Author.Contains(searchString) );
        }
        return View("index", users.ToList());
        }



    }
}