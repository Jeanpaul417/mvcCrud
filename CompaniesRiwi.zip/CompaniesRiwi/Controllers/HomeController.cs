using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CompaniesRiwi.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using CompaniesRiwi.Models.ViewModel;
using Microsoft.AspNetCore.Hosting;

namespace CompaniesRiwi.Controllers
{
  public class HomeController : Controller
  {
  private readonly IWebHostEnvironment _enviroment;

    public HomeController(IWebHostEnvironment env)
    {
       _enviroment = env;
    }

/* Subir imagenes a una carpeta */
    public IActionResult Index()
    {
        string webRootPath = _enviroment.WebRootPath;
        string imagenesFolderPath = Path.Combine(webRootPath, "uploads");
        string[] imagenesPaths = Directory.GetFiles(imagenesFolderPath);

        ViewBag.message = TempData["message"];
        return View(imagenesPaths);
    }

    public async Task<IActionResult> Upload2(UploadModel upload){// era aki _enviroment.WebRootPath tiene que ir esto  _enviroment.WebRootPath y ud tenia esto _enviroment.ContentRootPath
      var fileName = System.IO.Path.Combine(_enviroment.WebRootPath,"uploads", upload.MyFile.FileName);

      await upload.MyFile.CopyToAsync(new System.IO.FileStream(fileName, System.IO.FileMode.Create));

      TempData["message"] = "Archivo arriba";
      return RedirectToAction("Index");
    }     

     // Acción para mostrar la vista con la imagen cargada
    public IActionResult ShowImage()
    {
        var imagePath = Path.Combine("uploads", "gta 6 2.jpg"); // Ruta a la imagen cargada
        var model = new UploadModel { FileName = "gta g 2.jpg", FilePath = imagePath };
        return View(model);
    }

    // Método para eliminar un archivo
    public IActionResult DeleteFile(string fileName)
    {
        try
        {
            var filePath = Path.Combine(_enviroment.WebRootPath, "uploads", fileName);
            Console.WriteLine("larutica> > ");
            Console.WriteLine(filePath);
            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
                TempData["Message"] = $"El archivo {fileName} ha sido eliminado correctamente.";
            }
            else
            {
                TempData["Message"] = $"El archivo {fileName} no existe.";
            }
        }
        catch (Exception ex)
        {
            TempData["Message"] = $"Ocurrió un error al eliminar el archivo: {ex.Message}";
        }

        return RedirectToAction("Index"); // O redirige a donde desees
    }

  }
}

