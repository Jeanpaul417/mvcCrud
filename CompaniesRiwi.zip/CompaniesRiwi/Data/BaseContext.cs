using CompaniesRiwi.Models;
using Microsoft.EntityFrameworkCore;

namespace CompaniesRiwi.Data
{
    public class BaseContext : DbContext
    {
        public BaseContext(DbContextOptions<BaseContext> options) : base(options)
        {
        }

        public DbSet<Companie> Companies { get; set; }

        public DbSet<Sector> Sectors { get; set; }
    }
}