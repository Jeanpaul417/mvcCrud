using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Companies.Models;

namespace Companies.Services
{
    public interface ICompanyRepository
    {
        IEnumerable<Companie> GetAll();
        Companie GetById(int id);
        void Add(Companie companie);
        void remove(int id);
        void Update(int id, Companie companie);
    }
}