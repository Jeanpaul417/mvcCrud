using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Companies.Models;

namespace Companies.Services
{
    public class CompanyRepository : ICompanyRepository
    {
        void ICompanyRepository.Add(Companie companie)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Companie> ICompanyRepository.GetAll()
        {
            throw new NotImplementedException();
        }

        Companie ICompanyRepository.GetById(int id)
        {
            throw new NotImplementedException();
        }

        void ICompanyRepository.remove(int id)
        {
            throw new NotImplementedException();
        }

        void ICompanyRepository.Update(int id, Companie companie)
        {
            throw new NotImplementedException();
        }
    }
}