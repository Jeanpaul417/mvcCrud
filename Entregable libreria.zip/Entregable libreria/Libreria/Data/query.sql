CREATE TABLE Authors (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Name VARCHAR(125),
  LastName VARCHAR(45),
  Email VARCHAR(125),
  Nationality VARCHAR(125)
);

CREATE TABLE Editorials (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Name VARCHAR(125),
  Address VARCHAR(125),
  Phone VARCHAR(35),
  Email VARCHAR(125)
);

CREATE TABLE Books (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Title VARCHAR(255),
  Pages INT(10),
  Language VARCHAR(200),
  PublicationDate DATE,
  Description TEXT,
  AuthorId INTEGER,
  EditorialId INTEGER,
  FOREIGN KEY (AuthorId) REFERENCES Authors(id),
  FOREIGN KEY (EditorialId) REFERENCES Editorials(id)
);


ALTER TABLE Editorials ADD COLUMN IsDeleted BOOLEAN DEFAULT FALSE;

ALTER TABLE Authors ADD COLUMN IsDeleted BOOLEAN DEFAULT FALSE;

ALTER TABLE Books ADD COLUMN IsDeleted BOOLEAN DEFAULT FALSE;


INSERT INTO `Books`(`AuthorId`,`EditorialId`,`Description`,`PublicationDate`,`Language`,`Title`,`Pages`) VALUES(2,2,'dasfasdfasdf','2024-05-02','English','Libro 3',400);