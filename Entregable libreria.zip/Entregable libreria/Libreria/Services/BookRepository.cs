using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Libreria.Models;
using Microsoft.EntityFrameworkCore;
using Libreria.Data;

namespace Libreria.Services
{
    public class BookRepository : IBookRepository
    {
        private readonly BaseContext _context;

        public BookRepository(BaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Book> GetAll()
        {
            return _context.Books
                .Include(b => b.Author)
                .Include(b => b.Editorial)
                .Where(e => !e.IsDeleted)
                .ToList();
        }

        public Book GetById(int id)
        {
            return _context.Books
                .Include(b => b.Author)
                .Include(b => b.Editorial)
                .FirstOrDefault(e => e.id == id && !e.IsDeleted);
        }

        public void Add(Book book)
        {
            if (book != null)
            {
                _context.Books.Add(book);
                _context.SaveChanges();
            }
        }

        public void Remove(int id)
        {
            var book = _context.Books.Find(id);
            if (book != null)
            {
                book.IsDeleted = true;
                _context.Entry(book).State = EntityState.Modified;
                _context.SaveChanges();
            }
        }

        public async Task<bool> Update(Book book)
        {
            if (_context.Books.Local.Any(e => e.id == book.id))
            {
                _context.Entry(book).State = EntityState.Detached;
            }

            _context.Entry(book).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Books.Any(e => e.id == book.id))
                {
                    return false;
                }
                else
                {
                    throw;
                }
            }
        }

        public IEnumerable<Book> GetDeleted()
        {
            return _context.Books.Where(e => e.IsDeleted).ToList();
        }
    }
}
