using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Libreria.Models;

namespace Libreria.Services
{
    public interface IEditorialRepository
    {
        IEnumerable<Editorial> GetAll();
        Editorial GetById(int id);
        void Add(Editorial editorial);
        void Remove(int id);
        Task<bool> Update(Editorial editorial);

        IEnumerable<Editorial> GetDeleted();
    }
}