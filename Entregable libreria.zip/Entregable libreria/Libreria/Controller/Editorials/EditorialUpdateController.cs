using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Editorials
{   
    [ApiController]
    [Route("api/[controller]")]
    public class EditorialUpdateController : ControllerBase
    {
         private readonly IEditorialRepository _editorialRepository;

          public EditorialUpdateController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Editorial editorial)
        {
            if (id != editorial.id)
            {
                return BadRequest("ID mismatch");
            }

            var existingEditorial = _editorialRepository.GetById(id);
            if (existingEditorial == null)
            {
                return NotFound();
            }

            bool updateResult = await _editorialRepository.Update(editorial);

            if (!updateResult)
            {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            return NoContent();
        }
    }
}