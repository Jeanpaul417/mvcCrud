using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Editorials
{ 
    [ApiController]
    [Route("api/[controller]")]
    public class EditorialCreateController : ControllerBase
    {
         private readonly IEditorialRepository _editorialRepository;

          public EditorialCreateController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

        [HttpPost]
        public IActionResult Create([FromBody] Editorial editorial)
        {
            _editorialRepository.Add(editorial);
            return Ok();
        }
    }
}