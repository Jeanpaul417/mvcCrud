using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Books
{   
    [ApiController]
    [Route("api/[controller]")]
    public class BookUpdateController : ControllerBase
    {
         private readonly IBookRepository _bookRepository;

          public BookUpdateController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Book book)
        {
            if (id != book.id)
            {
                return BadRequest("ID mismatch");
            }

            var existingBook = _bookRepository.GetById(id);
            if (existingBook == null)
            {
                return NotFound();
            }

            bool updateResult = await _bookRepository.Update(book);

            if (!updateResult)
            {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            return NoContent();
        }

    }
}