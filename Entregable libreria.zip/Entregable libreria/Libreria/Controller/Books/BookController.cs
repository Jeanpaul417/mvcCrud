using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Data;
using Libreria.Models;
using Libreria.Services;

namespace Libreria.Controller.Books
{   
     [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
         private readonly IBookRepository _bookRepository;

          public BookController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

       [HttpGet]
        public ActionResult<IEnumerable<object>> GetBooks()
        {
            var books = _bookRepository.GetAll();

            var result = books.Select(book => new
            {
                book.id,
                book.Title,
                book.Pages,
                book.Language,
                book.PublicationDate,
                book.Description,
                book.AuthorId,
                AuthorName = book.Author?.Name,
                book.EditorialId,
                EditorialName = book.Editorial?.Name,
                book.IsDeleted
            });

            return Ok(result);
        }

        [HttpGet]
        [Route("{id}")]
        public Book Details(int id)
        {
            return _bookRepository.GetById(id);
        }
    }
}