using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Authors
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorDeleteController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;

        public AuthorDeleteController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var author = _authorRepository.GetById(id);
            if (author == null)
            {
                return NotFound();
            }

            _authorRepository.Remove(id);
            return NoContent();
        }

        // Nuevo endpoint para obtener editoriales eliminadas
        [HttpGet("deleted")]
        public IEnumerable<Author> GetDeletedAuthors()
        {
            return _authorRepository.GetDeleted();
        }
    }
}