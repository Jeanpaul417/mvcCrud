using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Libreria.Controller.Books
{   
    [ApiController]
    [Route("api/[controller]")]
    public class BookDeleteController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;

        public BookDeleteController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

         [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var book = _bookRepository.GetById(id);
            if (book == null)
            {
                return NotFound();
            }

            _bookRepository.Remove(id);
            return NoContent();
        }

        // Nuevo endpoint para obtener editoriales eliminadas
        [HttpGet("deleted")]
        public IEnumerable<Book> GetDeletedEditorials()
        {
            return _bookRepository.GetDeleted();
        }
    }
}