using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Authors
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorUpdateController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;

        public AuthorUpdateController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpPut("/{id}")]
        public IActionResult Update(int id, [FromBody] Author author)
        {
            if (id != author.id)
            {
                return BadRequest("ID mismatch");
            }

            var existingAuthor = _authorRepository.GetById(id);
            if (existingAuthor == null)
            {
                return NotFound();
            }

            _authorRepository.Update(author);

            return NoContent();
        }
    }
}
