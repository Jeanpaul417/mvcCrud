using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Authors
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorCreateController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;

        public AuthorCreateController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpPost]
        public IActionResult Create([FromBody] Author author)
        {
            _authorRepository.Add(author);
            return Ok();
        }
    }
}