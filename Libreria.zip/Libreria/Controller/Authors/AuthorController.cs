using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Data;
using Libreria.Models;
using Libreria.Services;

namespace Libreria.Controller.Authors
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;

        public AuthorController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpGet]
        public IEnumerable<Author> GetAuthors()
        {
            return _authorRepository.GetAll();
        }

        [HttpGet]
        [Route("{id}")]
        public Author Details(int id)
        {
            return _authorRepository.GetById(id);
        }

    }
}