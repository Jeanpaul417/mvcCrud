using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Libreria.Services;
using Libreria.Models;

namespace Libreria.Controller.Editorials
{   
    [ApiController]
    [Route("api/[controller]")]
    public class EditorialDeleteController : ControllerBase
    {
         private readonly IEditorialRepository _editorialRepository;

          public EditorialDeleteController(IEditorialRepository editorialRepository)
        {
            _editorialRepository = editorialRepository;
        }

       [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var editorial = _editorialRepository.GetById(id);
            if (editorial == null)
            {
                return NotFound();
            }

            _editorialRepository.Remove(id);
            return NoContent();
        }

        // Nuevo endpoint para obtener editoriales eliminadas
        [HttpGet("deleted")]
        public IEnumerable<Editorial> GetDeletedEditorials()
        {
            return _editorialRepository.GetDeleted();
        }
    }
}