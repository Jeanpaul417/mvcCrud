CREATE TABLE Authors (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Name VARCHAR(125),
  LastName VARCHAR(45),
  Email VARCHAR(125),
  Nationality VARCHAR(125)
);

CREATE TABLE Editorials (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Name VARCHAR(125),
  Address VARCHAR(125),
  Phone VARCHAR(35),
  Email VARCHAR(125)
);

CREATE TABLE Books (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  Title VARCHAR(255),
  Pages INT(10),
  Language VARCHAR(200),
  PublicationDate DATE,
  Description TEXT,
  AuthorId INTEGER,
  EditorialId INTEGER,
  FOREIGN KEY (AuthorId) REFERENCES Authors(id),
  FOREIGN KEY (EditorialId) REFERENCES Editorials(id)
);
