using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Libreria.Data;
using Libreria.Models;
using Microsoft.EntityFrameworkCore;

namespace Libreria.Services
{
    public class BookRepository : IBookRepository
    {
        private readonly BaseContext _context;

        public BookRepository(BaseContext context)
        {
            _context = context;
        }

         public IEnumerable<Book> GetAll()
        {
            // Excluir editoriales marcadas como eliminadas
            return _context.Books.Where(e => !e.IsDeleted).ToList();
        }

          public Book GetById(int id)
        {
            return _context.Books.FirstOrDefault(e => e.id == id && !e.IsDeleted);
        }
    }
}