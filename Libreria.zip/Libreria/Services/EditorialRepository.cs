using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Libreria.Data;
using Libreria.Models;
using Microsoft.EntityFrameworkCore;

namespace Libreria.Services
{
    public class EditorialRepository : IEditorialRepository
    {
        private readonly BaseContext _context;

        public EditorialRepository(BaseContext context)
        {
            _context = context;
        }

        public IEnumerable<Editorial> GetAll()
        {
            // Excluir editoriales marcadas como eliminadas
            return _context.Editorials.Where(e => !e.IsDeleted).ToList();
        }

        public Editorial GetById(int id)
        {
            return _context.Editorials.FirstOrDefault(e => e.id == id && !e.IsDeleted);
        }

        public void Add(Editorial editorial)
        {
            if (editorial != null)
            {
                _context.Editorials.Add(editorial);
                _context.SaveChanges();
            }
        }

        public void Remove(int id)
        {
            var editorial = _context.Editorials.Find(id);
            if (editorial != null)
            {
                // Cambiar el estado a eliminado
                editorial.IsDeleted = true;
                _context.Entry(editorial).State = EntityState.Modified;
                _context.SaveChanges();
            }
        }

        public async Task<bool> Update(Editorial editorial)
        {
            if (_context.Editorials.Local.Any(e => e.id == editorial.id))
            {
                _context.Entry(editorial).State = EntityState.Detached;
            }

            _context.Entry(editorial).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Editorials.Any(e => e.id == editorial.id))
                {
                    return false;
                }
                else
                {
                    throw;
                }
            }
        }

        // Implementación del nuevo método para obtener editoriales eliminadas
        public IEnumerable<Editorial> GetDeleted()
        {
            return _context.Editorials.Where(e => e.IsDeleted).ToList();
        }
    }
}
