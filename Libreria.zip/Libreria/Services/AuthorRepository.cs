using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Libreria.Data;
using Libreria.Models;
using Microsoft.EntityFrameworkCore;

namespace Libreria.Services
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly BaseContext _context;

        public AuthorRepository(BaseContext context)
        {
            _context = context;
        }

        public void Add(Author author)
        {
            _context.Authors.Add(author);
            _context.SaveChanges();
        }

        public IEnumerable<Author> GetAll()
        {
            return _context.Authors.ToList();
        }

        public Author GetById(int id)
        {
            return _context.Authors.AsNoTracking().FirstOrDefault(a => a.id == id);
        }

        public void Remove(int id)
        {
            var author = _context.Authors.Find(id);
            if (author != null)
            {
                _context.Authors.Remove(author);
                _context.SaveChanges();
            }
        }

        public async Task<bool> Update(Author author)
        {
            if (_context.Authors.Local.Any(e => e.id == author.id))
            {
                _context.Entry(author).State = EntityState.Detached;
            }

            _context.Entry(author).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Authors.Any(e => e.id == author.id))
                {
                    return false;
                }
                else
                {
                    throw;
                }
            }
        }
    }
}
