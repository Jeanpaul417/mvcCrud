using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Libreria.Data;
using Libreria.Models;

namespace Libreria.Services
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly BaseContext _context;

        public AuthorRepository(BaseContext context)
        {
            _context = context;
        }

        public void Add(Author author)
        {
            _context.Authors.Add(author);
            _context.SaveChanges();
        }

        public IEnumerable<Author> GetAll()
        {
            return _context.Authors.ToList();
        }

        public Author GetById(int id)
        {
            return _context.Authors.Find(id);
        }

        public void Remove(int id)
        {
            var author = _context.Authors.Find(id);
            if (author != null)
            {
                _context.Authors.Remove(author);
                _context.SaveChanges();
            }
        }

        /* Task <bool> IAuthorRepository.Update(Author author)
        {
            _context.Entry(author).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
        } */
    }
}
