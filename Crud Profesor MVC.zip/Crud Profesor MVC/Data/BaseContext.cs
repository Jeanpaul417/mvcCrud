using Microsoft.EntityFrameworkCore;
using Crud_Profesor_MVC.Models;


namespace Crud_Profesor_MVC.Data
{
    public class BaseContext : DbContext
    {
        public BaseContext(DbContextOptions<BaseContext> options) : base(options)
        {

        }
        //registramos nuestros modelos
        public DbSet<User> Users { get; set; }
    }
}
