using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BolsaEmplo2.Models.ViewModel
{
  public class UploadModel
  {
    public IFormFile? MyFile { get; set; }

    public string? FileName { get; set; }
    public string? FilePath { get; set; }

  }

}