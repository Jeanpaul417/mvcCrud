using BolsaEmplo2.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BolsaEmplo2.Models;
using BolsaEmpleo.Models;

namespace BolsaEmplo2.Controllers
{
    public class EmployeesController : Controller
    {
        public readonly BaseContext _context;

        public EmployeesController(BaseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(){
            return View(await _context.Employees.ToListAsync());
        }

         //Detalles ****************************************************************
         public async Task<IActionResult> Details(int id){

            return View(await _context.Employees.FirstOrDefaultAsync(m=> m.Id == id));
        }

        //Eliminar ***********************************************

        public async Task<IActionResult> Delete(int id){
             var user = await _context.Employees.FindAsync(id);
            _context.Employees.Remove(user); 
            await _context.SaveChangesAsync(); 
            return RedirectToAction("Index"); 
        } 

        //Editar 

        public async Task<IActionResult> Edit(int? id)
            {
            return View(await _context.Employees.FirstOrDefaultAsync(m => m.Id == id));
            }

       [HttpPost]
        public IActionResult Edit(int id, Employee user)
        {
        // Se agrega el usuario al dbset dentro de los modelos donde se esta mapeando los datos
        _context.Employees.Update(user);
        // Guarda los cambios del dbset en la Base de Datos
        _context.SaveChanges();
        // Redirecciona a la lista de Usuarios
        return RedirectToAction("index");
        }  

        /* CREAR *******************************************************/

        public IActionResult Create()
        {
            return View();
        }

        // Con esta vista lo que hacemos es poder pasarle el dato a crear lo agrege al contexto y actualize el contexto para poder indicar que se creo correctamente
        [HttpPost]
        public IActionResult Create(Employee u)
        {
        // Se agrega el usuario al dbset dentro de los modelos donde se esta mapeando los datos
        _context.Employees.Add(u);
        // Guarda los cambios del dbset en la Base de Datos
        _context.SaveChanges();
        // Redirecciona a la lista de Usuarios
        return RedirectToAction("index");
        }

        public async Task<IActionResult> Search(string? searchString)
        {
        var users = _context.Employees.AsQueryable();
        if (!string.IsNullOrEmpty(searchString))
        {
            users = users.Where(u => u.Names.Contains(searchString) || u.Email.Contains(searchString) || u.LastNames.Contains(searchString) || u.Gender.Contains(searchString) || u.Address.Contains(searchString) || u.CivilStatus.Contains(searchString) || u.About.Contains(searchString) || u.AcademicTitle.Contains(searchString) || u.Languages.Contains(searchString) || u.Area.Contains(searchString));
        }
        return View("index", users.ToList());
        } 
    }
}