using BolsaEmplo2.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BolsaEmplo2.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using BolsaEmplo2.Models.ViewModel;

namespace BolsaEmplo2.Controllers
{
    public class JobsController : Controller
    {
        public readonly BaseContext _context;

        public JobsController(BaseContext context)
        {
            _context = context;
        }

        /*private readonly IWebHostEnvironment _enviroment;
        public JobsController(IWebHostEnvironment env)
        {
        _enviroment = env;
        } */

        public async Task<IActionResult> Index(){
            return View(await _context.Jobs.ToListAsync());
        }

         //Detalles ****************************************************************
         public async Task<IActionResult> Details(int id){

            return View(await _context.Jobs.FirstOrDefaultAsync(m=> m.Id == id));
        }

        //Eliminar ***********************************************

        public async Task<IActionResult> Delete(int id){
             var user = await _context.Jobs.FindAsync(id);
            _context.Jobs.Remove(user); 
            await _context.SaveChangesAsync(); 
            return RedirectToAction("Index"); 
        } 

        //Editar 

        public async Task<IActionResult> Edit(int? id)
            {
            return View(await _context.Jobs.FirstOrDefaultAsync(m => m.Id == id));
            }

        [HttpPost]
        public IActionResult Edit(int id, Job user)
        {
        // Se agrega el usuario al dbset dentro de los modelos donde se esta mapeando los datos
        _context.Jobs.Update(user);
        // Guarda los cambios del dbset en la Base de Datos
        _context.SaveChanges();
        // Redirecciona a la lista de Usuarios
        return RedirectToAction("index");
        } 

        /* CREAR *******************************************************/

        public IActionResult Create()
        {
            return View();
        }

        // Con esta vista lo que hacemos es poder pasarle el dato a crear lo agrege al contexto y actualize el contexto para poder indicar que se creo correctamente
        [HttpPost]
        public IActionResult Create(Job u)
        {
        // Se agrega el usuario al dbset dentro de los modelos donde se esta mapeando los datos
        _context.Jobs.Add(u);
        // Guarda los cambios del dbset en la Base de Datos
        _context.SaveChanges();
        // Redirecciona a la lista de Usuarios
        return RedirectToAction("index");
        }

        public async Task<IActionResult> Search(string? searchString)
        {
        var users = _context.Jobs.AsQueryable();
        if (!string.IsNullOrEmpty(searchString))
        {
            users = users.Where(u => u.NameCompany.Contains(searchString) || u.Description.Contains(searchString) || u.OfferTitle.Contains(searchString) || u.Description.Contains(searchString) || u.Status.Contains(searchString) || u.Country.Contains(searchString) || u.Languages.Contains(searchString));
        }
        return View("index", users.ToList());
        }

        /* //Subir imagenes a una carpeta
        public IActionResult Index()
        {
            string webRootPath = _enviroment.WebRootPath;
            string imagenesFolderPath = Path.Combine(webRootPath, "uploads");
            string[] imagenesPaths = Directory.GetFiles(imagenesFolderPath);

            ViewBag.message = TempData["message"];
            return View(imagenesPaths);
        }

        public async Task<IActionResult> Upload2(UploadModel upload){
        var fileName = System.IO.Path.Combine(_enviroment.WebRootPath,"uploads", upload.MyFile.FileName);

        await upload.MyFile.CopyToAsync(new System.IO.FileStream(fileName, System.IO.FileMode.Create));

        TempData["message"] = "Archivo arriba";
        return RedirectToAction("Index");
        }      */
    }
}