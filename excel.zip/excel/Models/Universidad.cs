using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace excel.Models
{
    public class Universidad
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Decano { get; set; }

        public virtual ICollection<Inscripcion>? Inscripciones { get; set; }
    }
}