using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace excel.Models
{
    public class Materia
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public int Semestre { get; set; }
        public int Ano { get; set; }
        public int ProfesorId { get; set; }

        public virtual Profesor? Profesor { get; set; }
        public virtual ICollection<Inscripcion>? Inscripciones { get; set; }
    }
}