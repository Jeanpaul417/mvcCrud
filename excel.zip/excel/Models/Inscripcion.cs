using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace excel.Models
{
    public class Inscripcion
    {
        public int Id { get; set; }
        public int EstudianteId { get; set; }
        public int MateriaId { get; set; }
        public int CarreraId { get; set; }
        public int UniversidadId { get; set; }
        public string? Estado { get; set; }

        public virtual Estudiante? Estudiante { get; set; }
        public virtual Materia? Materia { get; set; }
        public virtual Carrera? Carrera { get; set; }
        public virtual Universidad? Universidad { get; set; }
    }
}