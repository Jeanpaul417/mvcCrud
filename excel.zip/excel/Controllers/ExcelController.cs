using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using excel.Models;
using excel.Data;
using Microsoft.EntityFrameworkCore;

namespace excel.Controllers
{
    public class ExcelController : Controller
    {
        private readonly BaseDbContext _context;

        public ExcelController(BaseDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> ExportToExcel()
        {
            var carreras = await _context.Carreras.ToListAsync();
            var estudiantes = await _context.Estudiantes.ToListAsync();
            var profesores = await _context.Profesores.ToListAsync();
            var materias = await _context.Materias.ToListAsync();
            var universidades = await _context.Universidades.ToListAsync();
            var inscripciones = await _context.Inscripciones.ToListAsync();

            using (var package = new ExcelPackage())
            {
                var sheet = package.Workbook.Worksheets.Add("Datos Consolidado");

                // Set headers
                sheet.Cells[1, 1].Value = "Nombre Carrera"; // Carrera
                sheet.Cells[1, 2].Value = "Nombre Estudiante"; // Estudiante
                sheet.Cells[1, 3].Value = "Apellido Estudiante"; // Estudiante
                sheet.Cells[1, 4].Value = "Correo Estudiante"; // Estudiante
                sheet.Cells[1, 5].Value = "Telefono Estudiante"; // Estudiante
                sheet.Cells[1, 6].Value = "Nombre Profesor"; // Profesor
                sheet.Cells[1, 7].Value = "Apellido Profesor"; // Profesor
                sheet.Cells[1, 8].Value = "Correo Profesor"; // Profesor
                sheet.Cells[1, 9].Value = "Telefono Profesor"; // Profesor
                sheet.Cells[1, 10].Value = "Nombre Materia"; // Materia
                sheet.Cells[1, 11].Value = "Semestre"; // Materia
                sheet.Cells[1, 12].Value = "Año"; // Materia
                sheet.Cells[1, 13].Value = "ProfesorId"; // Materia
                sheet.Cells[1, 14].Value = "Nombre Universidad"; // Universidad
                sheet.Cells[1, 15].Value = "Decano"; // Universidad
                sheet.Cells[1, 16].Value = "EstudianteId"; // Inscripción
                sheet.Cells[1, 17].Value = "MateriaId"; // Inscripción
                sheet.Cells[1, 18].Value = "CarreraId"; // Inscripción
                sheet.Cells[1, 19].Value = "UniversidadId"; // Inscripción
                sheet.Cells[1, 20].Value = "Estado"; // Inscripción

                // Fill data
                int rowIndex = 2;

                foreach (var carrera in carreras)
                {
                    var estudiantesEnCarrera = estudiantes.Where(e => e.Id == carrera.Id).ToList();
                    var inscripcionesEnCarrera = inscripciones.Where(i => i.CarreraId == carrera.Id).ToList();

                    foreach (var estudiante in estudiantesEnCarrera)
                    {
                        foreach (var inscripcion in inscripcionesEnCarrera)
                        {
                            var materia = materias.FirstOrDefault(m => m.Id == inscripcion.MateriaId);
                            var universidad = universidades.FirstOrDefault(u => u.Id == inscripcion.UniversidadId);
                            var profesor = profesores.FirstOrDefault(p => p.Id == (materia != null ? materia.ProfesorId : 0));

                            sheet.Cells[rowIndex, 1].Value = carrera.Nombre;
                            sheet.Cells[rowIndex, 2].Value = estudiante.Nombre;
                            sheet.Cells[rowIndex, 3].Value = estudiante.Apellido;
                            sheet.Cells[rowIndex, 4].Value = estudiante.Correo;
                            sheet.Cells[rowIndex, 5].Value = estudiante.Telefono;
                            sheet.Cells[rowIndex, 6].Value = profesor?.Nombre;
                            sheet.Cells[rowIndex, 7].Value = profesor?.Apellido;
                            sheet.Cells[rowIndex, 8].Value = profesor?.Correo;
                            sheet.Cells[rowIndex, 9].Value = profesor?.Telefono;
                            sheet.Cells[rowIndex, 10].Value = materia?.Nombre;
                            sheet.Cells[rowIndex, 11].Value = materia?.Semestre;
                            sheet.Cells[rowIndex, 12].Value = materia?.Ano;
                            sheet.Cells[rowIndex, 13].Value = materia?.ProfesorId;
                            sheet.Cells[rowIndex, 14].Value = universidad?.Nombre;
                            sheet.Cells[rowIndex, 15].Value = universidad?.Decano;
                            sheet.Cells[rowIndex, 16].Value = inscripcion.EstudianteId;
                            sheet.Cells[rowIndex, 17].Value = inscripcion.MateriaId;
                            sheet.Cells[rowIndex, 18].Value = inscripcion.CarreraId;
                            sheet.Cells[rowIndex, 19].Value = inscripcion.UniversidadId;
                            sheet.Cells[rowIndex, 20].Value = inscripcion.Estado;

                            rowIndex++;
                        }
                    }
                }

                var stream = new MemoryStream();
                package.SaveAs(stream);
                stream.Position = 0;

                string excelName = $"Datos_{DateTime.Now.ToString("yyyyMMddHHmmss")}.xlsx";

                return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelName);
            }
        }
    }
}
