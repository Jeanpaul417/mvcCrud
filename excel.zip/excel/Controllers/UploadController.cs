using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using excel.Data;
using excel.Models;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace excel.Controllers
{
    public class UploadController : Controller
    {
        private readonly BaseDbContext _context;

        public UploadController(BaseDbContext context)
        {
            _context = context;
        }

        // GET: Upload
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadExcel(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                TempData["Message"] = "Please select a valid Excel file.";
                return RedirectToAction("Index", "Home");
            }

            try
            {
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    using (var package = new ExcelPackage(stream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        int rowCount = worksheet.Dimension.Rows;

                        for (int row = 2; row <= rowCount; row++)
                        {
                            // Read data from the Excel file
                            string nombreCarrera = worksheet.Cells[row, 1].Text;
                            string nombreEstudiante = worksheet.Cells[row, 2].Text;
                            string apellidoEstudiante = worksheet.Cells[row, 3].Text;
                            string correoEstudiante = worksheet.Cells[row, 4].Text;
                            string telefonoEstudiante = worksheet.Cells[row, 5].Text;
                            string nombreProfesor = worksheet.Cells[row, 6].Text;
                            string apellidoProfesor = worksheet.Cells[row, 7].Text;
                            string correoProfesor = worksheet.Cells[row, 8].Text;
                            string telefonoProfesor = worksheet.Cells[row, 9].Text;
                            string nombreMateria = worksheet.Cells[row, 10].Text;
                            string semestreText = worksheet.Cells[row, 11].Text;
                            string anoText = worksheet.Cells[row, 12].Text;
                            string profesorIdText = worksheet.Cells[row, 13].Text;
                            string nombreUniversidad = worksheet.Cells[row, 14].Text;
                            string decanoUniversidad = worksheet.Cells[row, 15].Text;
                            string estudianteIdText = worksheet.Cells[row, 16].Text;
                            string materiaIdText = worksheet.Cells[row, 17].Text;
                            string carreraIdText = worksheet.Cells[row, 18].Text;
                            string universidadIdText = worksheet.Cells[row, 19].Text;
                            string estado = worksheet.Cells[row, 20].Text;

                            // Validate and convert data
                            if (string.IsNullOrWhiteSpace(semestreText) || !int.TryParse(semestreText, out int semestre))
                            {
                                TempData["Message"] = $"Invalid 'Semestre' data format in row {row}. Value: {semestreText}";
                                return RedirectToAction("Index", "Home");
                            }

                            if (string.IsNullOrWhiteSpace(anoText) || !int.TryParse(anoText, out int ano))
                            {
                                TempData["Message"] = $"Invalid 'Año' data format in row {row}. Value: {anoText}";
                                return RedirectToAction("Index", "Home");
                            }

                            if (string.IsNullOrWhiteSpace(profesorIdText) || !int.TryParse(profesorIdText, out int profesorId))
                            {
                                TempData["Message"] = $"Invalid 'ProfesorId' data format in row {row}. Value: {profesorIdText}";
                                return RedirectToAction("Index", "Home");
                            }

                            if (string.IsNullOrWhiteSpace(estudianteIdText) || !int.TryParse(estudianteIdText, out int estudianteId))
                            {
                                TempData["Message"] = $"Invalid 'EstudianteId' data format in row {row}. Value: {estudianteIdText}";
                                return RedirectToAction("Index", "Home");
                            }

                            if (string.IsNullOrWhiteSpace(materiaIdText) || !int.TryParse(materiaIdText, out int materiaId))
                            {
                                TempData["Message"] = $"Invalid 'MateriaId' data format in row {row}. Value: {materiaIdText}";
                                return RedirectToAction("Index", "Home");
                            }

                            if (string.IsNullOrWhiteSpace(carreraIdText) || !int.TryParse(carreraIdText, out int carreraId))
                            {
                                TempData["Message"] = $"Invalid 'CarreraId' data format in row {row}. Value: {carreraIdText}";
                                return RedirectToAction("Index", "Home");
                            }

                            if (string.IsNullOrWhiteSpace(universidadIdText) || !int.TryParse(universidadIdText, out int universidadId))
                            {
                                TempData["Message"] = $"Invalid 'UniversidadId' data format in row {row}. Value: {universidadIdText}";
                                return RedirectToAction("Index", "Home");
                            }

                            // Check foreign key constraints
                            if (!_context.Profesores.Any(p => p.Id == profesorId))
                            {
                                TempData["Message"] = $"Foreign key constraint violation: 'ProfesorId' {profesorId} not found in row {row}.";
                                return RedirectToAction("Index", "Home");
                            }

                            if (!_context.Estudiantes.Any(e => e.Id == estudianteId))
                            {
                                TempData["Message"] = $"Foreign key constraint violation: 'EstudianteId' {estudianteId} not found in row {row}.";
                                return RedirectToAction("Index", "Home");
                            }

                            if (!_context.Materias.Any(m => m.Id == materiaId))
                            {
                                TempData["Message"] = $"Foreign key constraint violation: 'MateriaId' {materiaId} not found in row {row}.";
                                return RedirectToAction("Index", "Home");
                            }

                            if (!_context.Carreras.Any(c => c.Id == carreraId))
                            {
                                TempData["Message"] = $"Foreign key constraint violation: 'CarreraId' {carreraId} not found in row {row}.";
                                return RedirectToAction("Index", "Home");
                            }

                            if (!_context.Universidades.Any(u => u.Id == universidadId))
                            {
                                TempData["Message"] = $"Foreign key constraint violation: 'UniversidadId' {universidadId} not found in row {row}.";
                                return RedirectToAction("Index", "Home");
                            }

                            // Insert data into database
                            var carrera = new Carrera { Nombre = nombreCarrera };
                            _context.Carreras.Add(carrera);

                            var estudiante = new Estudiante
                            {
                                Nombre = nombreEstudiante,
                                Apellido = apellidoEstudiante,
                                Correo = correoEstudiante,
                                Telefono = telefonoEstudiante
                            };
                            _context.Estudiantes.Add(estudiante);

                            var profesor = new Profesor
                            {
                                Nombre = nombreProfesor,
                                Apellido = apellidoProfesor,
                                Correo = correoProfesor,
                                Telefono = telefonoProfesor
                            };
                            _context.Profesores.Add(profesor);

                            var materia = new Materia
                            {
                                Nombre = nombreMateria,
                                Semestre = semestre,
                                Ano = ano,
                                ProfesorId = profesorId
                            };
                            _context.Materias.Add(materia);

                            var universidad = new Universidad
                            {
                                Nombre = nombreUniversidad,
                                Decano = decanoUniversidad
                            };
                            _context.Universidades.Add(universidad);

                            var inscripcion = new Inscripcion
                            {
                                EstudianteId = estudianteId,
                                MateriaId = materiaId,
                                CarreraId = carreraId,
                                UniversidadId = universidadId,
                                Estado = estado
                            };
                            _context.Inscripciones.Add(inscripcion);
                        }

                        await _context.SaveChangesAsync();
                    }
                }

                TempData["Message"] = "Excel file uploaded and data saved successfully.";
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                TempData["Message"] = $"An error occurred: {ex.Message}";
                return RedirectToAction("Index", "Home");
            }
        }
    }
}
