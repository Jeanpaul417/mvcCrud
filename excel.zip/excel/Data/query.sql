-- Active: 1722456790572@@bsnzeurehvlnmtjzeinp-mysql.services.clever-cloud.com@3306@bsnzeurehvlnmtjzeinp
CREATE TABLE Carreras (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(255)
);

CREATE TABLE Estudiantes (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(255),
    Apellido VARCHAR(255),
    Correo VARCHAR(255),
    Telefono VARCHAR(50)
);

CREATE TABLE Profesores (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(255),
    Apellido VARCHAR(255),
    Correo VARCHAR(255),
    Telefono VARCHAR(50)
);

CREATE TABLE Materias (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(255),
    Semestre INT,
    Ano INT,
    ProfesorId INT,
    FOREIGN KEY (ProfesorId) REFERENCES Profesores(Id)
);

CREATE TABLE Universidades (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(255),
    Decano VARCHAR(255)
);

CREATE TABLE Inscripciones (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    EstudianteId INT,
    MateriaId INT,
    CarreraId INT,
    UniversidadId INT,
    Estado VARCHAR(50),
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id),
    FOREIGN KEY (MateriaId) REFERENCES Materias(Id),
    FOREIGN KEY (CarreraId) REFERENCES Carreras(Id),
    FOREIGN KEY (UniversidadId) REFERENCES Universidades(Id)
);

DROP TABLE `Carrera`

DROP TABLE `Estudiante`

DROP TABLE `Materia`

DROP TABLE `Universidad`

DROP TABLE `Profesor`

DROP TABLE `Inscripcion`



-- Insertar datos en la tabla Carrera
INSERT INTO Carreras (Nombre) VALUES
('Ingeniería Informática'),
('Medicina'),
('Derecho'),
('Arquitectura'),
('Psicología');

-- Insertar datos en la tabla Estudiante
INSERT INTO Estudiantes (Nombre, Apellido, Correo, Telefono) VALUES
('Juan', 'Pérez', 'juan.perez@example.com', '1234567890'),
('María', 'González', 'maria.gonzalez@example.com', '0987654321'),
('Carlos', 'Rodríguez', 'carlos.rodriguez@example.com', '1122334455'),
('Ana', 'Martínez', 'ana.martinez@example.com', '5566778899'),
('Luis', 'Hernández', 'luis.hernandez@example.com', '6677889900');

-- Insertar datos en la tabla Profesor
INSERT INTO Profesores (Nombre, Apellido, Correo, Telefono) VALUES
('Roberto', 'Lopez', 'roberto.lopez@example.com', '1231231234'),
('Laura', 'Ramirez', 'laura.ramirez@example.com', '3213214321'),
('Fernando', 'Gomez', 'fernando.gomez@example.com', '4564564567'),
('Patricia', 'Diaz', 'patricia.diaz@example.com', '6546547654'),
('Jorge', 'Morales', 'jorge.morales@example.com', '7897890987');

-- Insertar datos en la tabla Materia
INSERT INTO Materias (Nombre, Semestre, Ano, ProfesorId) VALUES
('Matemáticas', 1, 2023, 1),
('Física', 2, 2023, 2),
('Química', 1, 2023, 3),
('Biología', 2, 2023, 4),
('Historia', 1, 2023, 5);

-- Insertar datos en la tabla Universidad
INSERT INTO Universidades (Nombre, Decano) VALUES
('Universidad Nacional', 'Dr. José Pérez'),
('Universidad de la Ciudad', 'Dra. María López'),
('Instituto Politécnico', 'Dr. Carlos Martínez'),
('Universidad del Sur', 'Dra. Ana Rodríguez'),
('Universidad del Norte', 'Dr. Luis González');

-- Insertar datos en la tabla Inscripcion
INSERT INTO Inscripciones (EstudianteId, MateriaId, CarreraId, UniversidadId, Estado) VALUES
(1, 1, 1, 1, 'Activo'),
(2, 2, 2, 2, 'Activo'),
(3, 3, 3, 3, 'Activo'),
(4, 4, 4, 4, 'Inactivo'),
(5, 5, 5, 5, 'Activo');
