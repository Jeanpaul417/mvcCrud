
using excel.Models;
using Microsoft.EntityFrameworkCore;

namespace excel.Data
{
    public class BaseDbContext : DbContext
    {
        public BaseDbContext(DbContextOptions<BaseDbContext> options) : base(options)
        {

        }

        public DbSet<Estudiante> Estudiantes { get; set; }
        public DbSet<Profesor> Profesores { get; set; }
        public DbSet<Materia> Materias { get; set; }
        public DbSet<Carrera> Carreras { get; set; }
        public DbSet<Universidad> Universidades { get; set; }
        public DbSet<Inscripcion> Inscripciones { get; set; }
    }
}